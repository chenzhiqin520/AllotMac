/* opensslv.h compatibility */

#include <wolfssl/openssl/opensslv.h>
